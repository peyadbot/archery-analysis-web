<!-- Main footer tamplate -->
<footer class="bg-body-tertiary ext-center text-lg-start text-white p-4 mt-auto" data-bs-theme="dark">
    <!-- Copyright -->
    <div class="text-center p-3">
        © 2024 Copyright
        <a class="text-body" href="#">redpanda.com</a>
    </div>
    <!-- Copyright -->
</footer>